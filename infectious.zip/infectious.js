const passengers = require("./people.json");
const testReport = require("./testReport.json");
const fs = require("fs");

let DNA = [];
let passengersAtRisk = [];
let matchingDNA = [];


fs.readFile("infectiousdiseases.csv", "utf8", function (err, data) {
  let dataArray = data.split(/\r?\n/);

  //lager en liste med alle DNA kodene.

  for (let i = 0; i < dataArray.length; i++) {
    DNA.push(dataArray[i].slice(-18));
  }

  DNA.shift();
  //sjekker om DNA koden samsvarer med passasjerDNAkoden.
  for (let i = 0; i < passengers.length; i++) {
    passengers[i].testData = testReport.testData[i].testData;
    let pasDNA = passengers[i].testData.toString();


    for (let y = 0; y < DNA.length; y++) {
      if (pasDNA.includes(DNA[y])) {
        passengersAtRisk.push(passengers[i].name);
        matchingDNA.push(DNA[y]);
      }

    }
  }

   console.log(matchingDNA);
   console.log(passengersAtRisk);
});





//lage ny json fil.


const newObject = {
    name: "Per Simen",
    age: "22",
    adress: "Tønnevoldsgate 2",
};

const jsonString = JSON.stringify(newObject);

fs.writeFile('./rapport.json', JSON.stringify(newObject, null, 2), err => {
    if (err) {
        console.log(err);
    }else{
        console.log('File successfully written!');
    }
});

/*fs.writeFile('./rapport.html', JSON.stringify(newObject, null, 2), err => {
    if (err) {
        console.log(err);
    }else{
        console.log('File successfully written!');
    }
});
*/
