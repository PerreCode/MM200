const parseCSV = function(data,separator){
    separator = separator || ",";

return data.split("\n").map(item =>item.split(separator));

}

module.export = parseCSV;